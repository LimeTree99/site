from django.contrib import admin
from music.models import song, album

admin.site.register(album)
admin.site.register(song)

