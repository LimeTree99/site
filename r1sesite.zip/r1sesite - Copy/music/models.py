from django.db import models

class album(models.Model):
    name = models.CharField(max_length = 140, default='')
    released = models.DateField()

    def __str__(self):
        return self.name

class song(models.Model):
    #this is a table
    title =  models.CharField(max_length = 140, default='')
    number = models.IntegerField()
    song_file = models.FileField(upload_to='music_folder/', null=True)
    #album_name = models.ForeignKey(album, on_delete=models.CASCADE)

    def __str__(self):
        return '{} {}'.format(str(self.number), self.title)
