from django.conf.urls import url, include
from django.views.generic import ListView, DetailView
from music.models import song

urlpatterns = [
    url(r'^$', ListView.as_view(
        queryset=song.objects.all().order_by('number'),
        template_name="music/music.html"
    ))
]
