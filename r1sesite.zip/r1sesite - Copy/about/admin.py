from django.contrib import admin
from about.models import page


admin.site.register(page)
